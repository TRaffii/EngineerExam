Wersja 1.12 wymaga po��czenia z internetem
Spos�b aktywacji programu:
Program musi zosta� aktywowany poprzez podanie klucza aktywuj�cego przesy�anego e-mailem
Raz aktywowany program nie b�dzie pyta� ponownie o has�o na danym systemie

Aktywacja:
1. Uruchom program, zostaniesz poproszony o podanie maila oraz imienia i nazwiska, po potwierdzeniu wys�ania informacji do
	administrator�w zamknij wszystkie okna aplikacji.
2. Po uzyskaniu kodu aktywacyjnego uruchom ponownie program, wprowad� otrzymany klucz aktywacyjny, je�li wszystko przebieg�o poprawnie
	program zostanie aktywowany i nie b�dzie pyta�o aktywacje. 
	
Praca z programem:
Program podzielony jest na kilka modu��w nauki - menu PLIK:
	1. Nowy test - standardowy tryb przeprowadzenia egzaminu, nale�y przej�� przez wszystkie pytania po czy u�ytkownik otrzymuje zestawienie 
		wynik�w
	2. Nowy test - szybkie odpowiedzi - u�ytkownik od razu widzi czy dokona� prawid�owej odpowiedzi, na ko�cu zostanie wy�wietlone zestawienie 
	3. Aktywuj wszystkie pytania - powr�t do ekranu startowego zostaj� za�adowane wszystkie pytania do przegl�dania

Menu "Zakres pyta�" - umo�liwia wyb�r losowania lub przegl�dania pyta� tylko z danej kategorii pomocne do nauki
Ilo�� testowych pyta�  - umo�liwia wyb�r ilo�ci pyta� do ka�dego testu (standardowo 5)

Admin - Podgl�d odpowiedzi/ Tryb nauki - uaktywnia podgl�d wszystkich dost�pnych odpowiedzi 